window.addEventListener("load", examen);
function examen() {
    provincias = new Map();
    provincias.set("GA", ["La Coruña", "Lugo", "Orense", "Pontevedra"]);
    provincias.set("CL", ["Ávila", "Burgos", "León", "Palencia", "Salamanca", "Segovia", "Soria", "Valladolid", "Zamora"]);
    provincias.set("EX", ["Badajoz", "Cáceres"]);
    provincias.set("PV", ["Álava", "Vizcaya", "Guipúzcoa"]);

    nombre = document.getElementById("nombre");
    apellidos = document.getElementById("apellidos");
    edad = document.getElementById("edad");
    comunidades = document.getElementById("ccaa");
    provincia = document.getElementById("provincia");
    destinoArrastrable = document.querySelector(".resultado");
    num1 = document.getElementById("num1");
    num2 = document.getElementById("num2");
    botonEnviar = document.getElementById("enviar");
    captcha = document.getElementById("captcha");
    formulario = document.getElementById("formulario");
    botonWeb = document.getElementById("btnweb");
    botonDOM = document.getElementById("btndom");
    botonInformacion = document.getElementById("btninfo");
    cuadroDOM = document.getElementById("DOM");
    cuadroInformacion = document.getElementById("informacion");
    pie = document.getElementById("pie");

    validarNombre = /^\w{3}/;
    validarApellidos = /^\w{2,}\s\w{2,}/;
    validarEdad = /^(10\d|110)|^(\d{1,2})$/;

    nombre.addEventListener("keyup", comprobarNombre);
    nombre.addEventListener("focusout", mayusculas);
    function comprobarNombre(e) {
        if (validarNombre.test(e.target.value)) {
            e.target.classList.remove("error");
            e.target.classList.add("correcto");
        } else {
            e.target.classList.remove("correcto");
            e.target.classList.add("error");
        }
    }

    apellidos.addEventListener("keyup", comprobarApellidos);
    apellidos.addEventListener("focusout", mayusculas);
    function comprobarApellidos(e) {
        if (validarApellidos.test(e.target.value)) {
            e.target.classList.remove("error");
            e.target.classList.add("correcto");
        } else {
            e.target.classList.remove("correcto");
            e.target.classList.add("error");
        }
    }
    function mayusculas(e) {
        e.target.value = e.target.value.toUpperCase();
    }


    edad.addEventListener("keyup", comprobarEdad);
    function comprobarEdad(e) {
        if (validarEdad.test(e.target.value)) {
            e.target.classList.remove("error");
            e.target.classList.add("correcto");
        } else {
            e.target.classList.remove("correcto");
            e.target.classList.add("error");
        }
    }
    botonWeb.addEventListener("click",mostrarMiWeb);
    function mostrarMiWeb(e) {
        let features="width=1000,height=500";
       let ventana= window.open("https:daw201.ieslossauces.es/DWEC/index.html","",features);
       let cerrar=document.createElement("button");
       cerrar.classList.add("cerrar");
       cerrar.textContent=("Cerrar mi web");
       pie.append(cerrar);
       cerrar.addEventListener("click",(e)=>{
        ventana.close();
        pie.removeChild(cerrar);
       });
    }
    botonDOM.addEventListener("click",abrirDOM);
    function abrirDOM(e) {
        cuadroDOM.textContent=document.head.innerHTML+"----------BODY-----------"+document.body.innerHTML;
        cuadroDOM.style.display="block";
        let cerrar=document.createElement("button");
        cerrar.classList.add("cerrar");
        cerrar.textContent=("Cerrar DOM");
        pie.append(cerrar);
        cerrar.addEventListener("click",(e)=>{
         cuadroDOM.style.display="none";
         pie.removeChild(cerrar);
        }); 
    }
    comunidades.addEventListener("focusout",listarProvincias);
    
    
    function listarProvincias(e) {
        let com=provincias.get(e.target.value);
       for (let index = 0; index < com.length; index++) {
        opcion=document.createElement("option");
        opcion.classList.add("provincia");
        opcion.textContent=com[index];
        provincia.appendChild(opcion);
        
       }
    }
}
